package com.example.demoMysqlApi;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demoMysqlApi.Model.Student;
import com.example.demoMysqlApi.Repository.StudentRepo;

@SpringBootTest
class DemoMysqlApiApplicationTests {

    @Autowired
    private StudentRepo studentRepo;

    @Test
    public void testCreate() {
        Student s = new Student();
        s.setSid(1);
        s.setSname("akash");
        s.setScollege("jss");
        s.setAddress("fdsgg");
        studentRepo.save(s);
        s.setSid(2);
        s.setSname("shreyas");
        s.setScollege("jss");
        s.setAddress("fdsgg");
        studentRepo.save(s);
        s.setSid(3);
        s.setSname("yashas");
        s.setScollege("jss");
        s.setAddress("fdsgg");
        studentRepo.save(s);
       
    }

    @Test
    public void testReadAll() {
        Iterable<Student> list = studentRepo.findAll();
        System.out.println(list);
      
    }

    @Test
    public void testUpdate() {
        Student s = studentRepo.findById(1).get();
            s.setSname("hitesh");
            studentRepo.save(s);
          
    }

    @Test
    public void testDelete() {
        studentRepo.deleteById(2);

    }
}
