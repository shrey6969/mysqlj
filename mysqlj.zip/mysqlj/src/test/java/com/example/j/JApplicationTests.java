package com.example.j;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.j.model.Student;
import com.example.j.repository.StudentRepo;

@SpringBootTest
class JApplicationTests {

    @Autowired
    private StudentRepo studentRepo;

    @Test
    public void testCreate() {
        Student s = new Student();
        s.setSid(4);
        s.setSname("Kavya");
        studentRepo.save(s);
       
    }

    @Test
    public void testReadAll() {
        List<Student> list = studentRepo.findAll();
        System.out.println(list);
      
    }

    @Test
    public void testUpdate() {
        Student s = studentRepo.findById(3).get();
            s.setSname("uuuuu");
            studentRepo.save(s);
          
    }

    @Test
    public void testDelete() {
        studentRepo.deleteById(1);

    }
}
