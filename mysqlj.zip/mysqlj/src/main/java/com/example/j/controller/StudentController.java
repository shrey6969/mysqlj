package com.example.j.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.j.model.Student;
import com.example.j.repository.StudentRepo;


@RestController
public class StudentController {
	
	@Autowired
	StudentRepo studentrepo;
	
	@PostMapping("/addStudent")
	public String addStudent(@RequestBody Student stu) {
		studentrepo.save(stu);
		return "Record Inserted Successfully";
	}
	@GetMapping("/display")
	public List<Student> display(){
		return studentrepo.findAll();
	}
	@DeleteMapping("/delete/{sid}")
	public String sdelete(@PathVariable int sid) {
		studentrepo.deleteById(sid);
		return "delete successfully";
	}
	@PutMapping("/update/{sid}")
	public String supdate(@RequestBody Student stu,@PathVariable int sid) {
		studentrepo.deleteById(sid);
		studentrepo.save(stu);		
		return "record updated successfully at Id:"+""+stu.getSid();
		
	}
	
}
