package com.example.demoMysqlApi.Controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demoMysqlApi.Model.Student;
import com.example.demoMysqlApi.Repository.StudentRepo;

@RestController
public class StudentController {
	
	@Autowired
	StudentRepo studentrepo;
	
	@PostMapping("/addStudent")
	public String addStudent(@RequestBody Student stu) {
		studentrepo.save(stu);
		return "Record Inserted Successfully";
	}
	@GetMapping("/display/{sid}")
	public Optional<Student> display(@PathVariable int sid){
		return studentrepo.findById(sid);
	}
	@DeleteMapping("/delete/{sid}")
	public String delete(@PathVariable int sid) {
		studentrepo.deleteById(sid);
		return "delete successfully";
	}
	@PutMapping("/update/{sid}")
	public String update(@RequestBody Student stu, @PathVariable int sid) {
		studentrepo.deleteById(sid);
		studentrepo.save(stu);
		return "record updated successfully at Id:"+" "+sid;
		
	}
	
}
